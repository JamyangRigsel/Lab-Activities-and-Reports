from PIL import Image 
# create an image via import  
image = Image.open('2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG')
# analyze the image  
print(image.size) 
print(image.filename) 
print(image.format) 

# exercise  
img_rotated = image.rotate(30) 
img_rotated.save('img_rotated.png', 'png')

image.show() 